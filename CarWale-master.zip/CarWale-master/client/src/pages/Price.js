export const Price = [
    {
      _id: 0,
      name: "₹1 to 50 Lakhs",
      array: [1, 50],
    },
    {
      _id: 1,
      name: "₹51 to 100 Lakhs",
      array: [51, 100],
    },
    {
      _id: 2,
      name: "₹101 to 150 Lakhs",
      array: [101, 150],
    },
    {
      _id: 3,
      name: "₹151 to 200 Lakhs",
      array: [151, 200],
    },
    {
      _id: 4,
      name: "₹201 to 250 Lakhs",
      array: [201, 250],
    },
    {
      _id: 4,
      name: "₹251 or more",
      array: [251, 9999],
    },
  ];